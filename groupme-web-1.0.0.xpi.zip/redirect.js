browser.spacesToolbar.addButton('GroupMe', {
    title: "GroupMe Web",
    defaultIcons: "groupme.svg",
    url: "https://web.groupme.com/"
});